# -*- coding: utf-8 -*-
"""
Created on Thu May  9 09:40:27 2019

@author: joslaton
"""


#MIPI SPEC DEPENDENT Constants
PM_TRIG = 28 
ID_REGS = [29,30,31,32]
REV_ID = 33
GSID = 34 
UDR_RST = 35
ERR_SUM = 36
INT_MAP1 = 37
INT_MAP2 = 38
INT_EN0 = 39
INT_EN1 = 40
INT_CLR0 = 41
INT_CLR1 = 42
BUS_LD = 43
TEST_PATT = 44
EXT_TRIGGER_MASK = 45
EXT_TRIGGER = 46
TEMP_SENSOR = 67
FB_READBACK = [128,129,130,131]
FUSE = 160
BANK = 161
SIREV_ID = 164
MIM_SELECT = 165
MIM_COUNT1 = 166
MIM_COUNT2 = 167
trig_dict = {'TRIGGER0':0, 'TRIGGER1':1,'TRIGGER2':2,'EXT_TRIGGER_3':3,
                 'EXT_TRIGGER_4':4,'EXT_TRIGGER_5':5,'EXT_TRIGGER_6':6,
                 'EXT_TRIGGER_7':7,'EXT_TRIGGER_8':8,'EXT_TRIGGER_9':9,
                 'EXT_TRIGGER_10':10}

control_reg_lst = [ PM_TRIG, GSID, UDR_RST,
                    ERR_SUM, BUS_LD, EXT_TRIGGER_MASK,
                    EXT_TRIGGER, SIREV_ID, TEMP_SENSOR,
                    TEST_PATT, FUSE, BANK,
                    MIM_SELECT, MIM_COUNT1, MIM_COUNT2]

control_reg_lst += ID_REGS
control_reg_lst += FB_READBACK
has_bits_reserved_lst = [0] 
trg_cntr_reg_lst = []#[56,57,58,59,60,61,62,63]   
rw_change_lst = []
exclude_lst = control_reg_lst + trg_cntr_reg_lst + rw_change_lst + has_bits_reserved_lst

class register:
    def __init__(self,line):
        self.ireq = line[0]
        self.address = int(line[1])
        self.address_hex = line[2]
        if 'x' in line[3]:
            self.default = int(line[3],16)
        else:
            self.default = int(line[3])
        self.trig_sup = line[4]
        self.trigger = line[5]
        self.ext_rw = line[6]
        self.mask_rw = line[7]
        self.r_w = line[8]
    def __repr__(self):
        rep_str =  'ireq : ' + self.ireq +'\n'
        rep_str += 'address : ' + str(self.address) +'\n'
        rep_str += 'address_hex : ' + self.address_hex +'\n'
        rep_str += 'default : ' + str(self.default) +'\n'
        rep_str += 'trig_sup : ' + self.trig_sup +'\n'
        rep_str += 'trigger : ' + self.trigger +'\n'
        rep_str += 'ext_rw : ' + self.ext_rw +'\n'
        rep_str += 'mask_rw : ' + self.mask_rw +'\n'
        rep_str += 'r_w : ' + self.r_w +'\n'
        return rep_str

def register_pack_generator(indir,in1,in2):
    a = []

    with open(indir + in1,'r') as f:
        f.readline()
        for line in f.readlines():
          a+=[register(line.strip('\n').split(','))]    
    with open(indir + in2,'r') as f:
        f.readline()
        for line in f.readlines():
          a += [register(line.strip('\n').split(','))]
    b = [False for i in range(a[-1].address+1)]
    for el in a:
        b[el.address] = el
    return b
        
def cmd_str_generator(enabled,typ,usid,regaddr,wrt_msk,reg_wrt_data,exp_rd_data,regwrary=[]):
    cmd_str = str(enabled) + ','
    cmd_str += str(typ) + ','
    cmd_str += str(usid) + ','
    cmd_str += str(regaddr) + ','
    cmd_str += str(wrt_msk) + ','
    cmd_str += str(reg_wrt_data) + ','
    cmd_str += str(exp_rd_data) + '\n'
    if regwrary:
        assert type(regwrary)==list
        assert len(regwrary)<5
        cmd_str = cmd_str.strip('\n') + ','
        for val in regwrary:
            cmd_str += str(val) + ','
        cmd_str += '\n'
    return [cmd_str]

def read_cmd_generator(reg,usid,erd):
    return cmd_str_generator(1,2,usid,reg.address,0,0,erd)

def extend_read_cmd_generator(reg,usid,erd,ary=[]):
    return cmd_str_generator(1,4,usid,reg.address,0,0,erd,regwrary=ary)

def write_cmd_generator(reg,usid,wrt):
    return cmd_str_generator(1,1,usid,reg.address,0,wrt,0)

def extend_write_cmd_generator(reg,usid,wrt,ary=[]):
    typ=3
    if ary:
        typ='1' + str(len(ary))
    return cmd_str_generator(1,typ,usid,reg.address,0,wrt,0,regwrary=ary)

def msk_wrt_cmd_generator(reg,usid,msk,wrt):
    return cmd_str_generator(1,5,usid,reg.address,msk,wrt,0)

def check_err_cmd_generator(usid,exp_read_err=False):
    if exp_read_err:
        return cmd_str_generator(1,2,usid,ERR_SUM,0,0,4)
    return cmd_str_generator(1,2,usid,ERR_SUM,0,0,-1)

def pwr_rst_cmd_generator(usid,useusid=False):
    if useusid:
        return write_cmd_generator(a[PM_TRIG],usid,64)
    return write_cmd_generator(a[PM_TRIG],0,64)

def udr_rst_cmd_generator(usid):
    return write_cmd_generator(a[UDR_RST],usid,128)

def pm_trig_trigger_cmd_generator(usid,trigger):
    return write_cmd_generator(a[PM_TRIG],usid,2**trigger)

def ext_trig_trigger_cmd_generator(usid,trigger):
    return write_cmd_generator(a[EXT_TRIGGER],usid,2**(trigger-3))

def rm_pm_trig_msk_cmd_generator(usid):
    return write_cmd_generator(a[PM_TRIG],usid,0)

def rm_ext_trig_msk_cmd_generator(usid):
    return write_cmd_generator(a[EXT_TRIGGER_MASK],usid,0)

def set_pm_trig_mask_cmd_generator(usid,mask='all'):
    if ( mask=='all' ):
        return write_cmd_generator(a[PM_TRIG],usid,56)
    else:
        assert type(int(mask))==int
        return write_cmd_generator(a[PM_TRIG],usid,2**(mask+3))

def set_ext_trig_mask_cmd_generator(usid,mask='all'):
    if ( mask == 'all' ):
        return write_cmd_generator(a[EXT_TRIGGER_MASK],usid,255)
    else:
        assert type(int(mask))==int
        return write_cmd_generator(a[EXT_TRIGGER_MASK],usid,2**(mask-3))

def usid_prog_cmd_generator(usid,v1,v2,v3):
    cmd_lst = write_cmd_generator(a[29],usid,v1)
    cmd_lst += write_cmd_generator(a[30],usid,v2)
    cmd_lst += write_cmd_generator(a[31],usid,v3)
    return cmd_lst

def reg_zero_write(usid):
    cmd_lst = pwr_rst_cmd_generator(usid)
    cmd_lst += set_pm_trig_mask_cmd_generator(usid)
    cmd_lst += read_cmd_generator(a[PM_TRIG],usid,56)
    #cmd_lst += cmd_str_generator(1,4,usid,SIREV_ID,0,0,-1)
    cmd_lst += cmd_str_generator(1,0,usid,0,0,15,0)
    cmd_lst += read_cmd_generator(a[0],usid,15)
    cmd_lst += rm_pm_trig_msk_cmd_generator(usid)
    cmd_lst += cmd_str_generator(1,0,usid,0,0,8,0)
    cmd_lst += read_cmd_generator(a[0],usid,15)
    cmd_lst += pm_trig_trigger_cmd_generator(usid,trig_dict[a[0].trigger])
    cmd_lst += read_cmd_generator(a[0],usid,8)
    return cmd_lst

def prog_USID(usid1,usid2):
    #todo: traverse every usid 1-15
    def priv_prog_usid_read_block(usid,offset=0):
        cmd_lst = check_err_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[29],usid,a[29].default)
        cmd_lst += check_err_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[30],usid,a[30].default)
        cmd_lst += check_err_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[31],usid,a[31].default-offset)
        cmd_lst += check_err_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[32],usid,a[32].default)
        cmd_lst += check_err_cmd_generator(usid)
        return cmd_lst
    
    def priv_prog_usid_block1(usid,offset):
        val_ary = [a[ID_REGS[0]].default,
                   a[ID_REGS[1]].default,
                   a[ID_REGS[2]].default-offset]
        cmd_lst = priv_prog_usid_read_block(usid)
        cmd_lst += extend_write_cmd_generator(a[29],usid,0,ary=val_ary)
        return cmd_lst
        
    def priv_prog_usid_block2(usid,offset):
        cmd_lst = priv_prog_usid_read_block(usid,offset=offset)
        cmd_lst += udr_rst_cmd_generator(usid)
        cmd_lst += pwr_rst_cmd_generator(usid)
        return cmd_lst
    
    cmd_lst = pwr_rst_cmd_generator(usid1)
    cmd_lst += check_err_cmd_generator(usid1)
    '''
    cmd_lst += write_cmd_generator(a[SIREV_ID],usid1,113)
    cmd_lst += check_err_cmd_generator(usid1)
    cmd_lst += read_cmd_generator(a[SIREV_ID],usid1,a[SIREV_ID].default)
    '''
    cmd_lst += priv_prog_usid_read_block(usid1)
    
    cmd_lst += write_cmd_generator(a[29],usid1,a[29].default)
    cmd_lst += write_cmd_generator(a[30],usid1,a[30].default)
    cmd_lst += write_cmd_generator(a[31],usid1,a[31].default-(usid1-usid2))
    
    cmd_lst += priv_prog_usid_block2(usid2,usid1-usid2)
    
    cmd_lst += priv_prog_usid_block1(usid1,usid1-usid2)
    
    cmd_lst += priv_prog_usid_block2(usid2,usid1-usid2)
    
    cmd_lst += priv_prog_usid_block1(usid1,usid1-usid2)
    
    cmd_lst += priv_prog_usid_block2(usid2,usid1-usid2)
    
    cmd_lst += priv_prog_usid_block1(usid1,usid1-usid2)[:-3]
    
    return cmd_lst
    
def mask_write_tester(usid):
    b = [reg for reg in a if type(reg)!=bool]
    b = [reg.address for reg in b if reg.mask_rw=='Yes']
    cmd_lst = []
    for addrs in b:
        cmd_lst += pwr_rst_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[PM_TRIG],usid,128)
        cmd_lst += set_pm_trig_mask_cmd_generator(usid)
        cmd_lst += set_ext_trig_mask_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[PM_TRIG],usid,56)
        cmd_lst += check_err_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[addrs],usid,4)
        cmd_lst += read_cmd_generator(a[addrs],usid,4)
        cmd_lst += check_err_cmd_generator(usid)
        cmd_lst += msk_wrt_cmd_generator(a[addrs],usid,247,255)
        cmd_lst += check_err_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[addrs],usid,12)
        cmd_lst += check_err_cmd_generator(usid)
    return cmd_lst

def timed_triggers(usid):
    #todo: add counter at end for trig9
    def set_clk_top_cmd_gen(usid,clk):
        return write_cmd_generator(clk,usid,255)
    def read_clk_mult_cmd_gen(usid):
        c = [244,228,211,195,178,162,145,129,112,96,79,63,46,30,13,0]
        cmd_lst = []
        for el in c:
            cmd_lst += read_cmd_generator(a[63],usid,el)
        return cmd_lst
    
    b = [reg for reg in a if type(reg)!=bool]
    b = [reg.address for reg in b if reg.trigger=='EXT_TRIGGER_10']
    cmd_lst = []
    for addrs in b:
        cmd_lst += pwr_rst_cmd_generator(usid)
        cmd_lst += rm_pm_trig_msk_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[addrs],usid,a[addrs].default)
        cmd_lst += rm_ext_trig_msk_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[addrs],usid,127)
        cmd_lst += read_cmd_generator(a[addrs],usid,a[addrs].default)
        cmd_lst += set_clk_top_cmd_gen(usid,a[63])# if a[addrs].trigger=='EXT_TRIGGER_8' else a[62])
        cmd_lst += read_cmd_generator(a[addrs],usid,a[addrs].default)*21
        cmd_lst += read_cmd_generator(a[addrs],usid,127)*5
    cmd_lst += pwr_rst_cmd_generator(usid)
    cmd_lst += rm_pm_trig_msk_cmd_generator(usid)
    cmd_lst += read_cmd_generator(a[b[0]],usid,a[b[0]].default)
    cmd_lst += rm_ext_trig_msk_cmd_generator(usid)
    cmd_lst += write_cmd_generator(a[b[0]],usid,127)
    cmd_lst += read_cmd_generator(a[b[0]],usid,a[b[0]].default)
    cmd_lst += set_clk_top_cmd_gen(usid,a[63])
    cmd_lst += read_clk_mult_cmd_gen(usid)
    cmd_lst += read_cmd_generator(a[b[0]],usid,127)*2
    return cmd_lst
        
def default_values_test(usid,ctrl):
    def priv_dvt_write_all(usid,b):
        cmd_lst = []
        for adrs in b:
            cmd_lst += write_cmd_generator(a[adrs],usid,255)
        return cmd_lst
    def priv_dvt_read_all(usid,c,d):
        cmd_lst = []
        for adrs in c:
            cmd_lst += read_cmd_generator(a[adrs],usid,a[adrs].default)
            cmd_lst += check_err_cmd_generator(usid)
        for adrs in d:
            cmd_lst += read_cmd_generator(a[adrs],usid,a[adrs].default)
            cmd_lst += check_err_cmd_generator(usid,exp_read_err=True)
        return cmd_lst
    def priv_dvt_write_sequence(usid,b):
        cmd_lst = set_pm_trig_mask_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[EXT_TRIGGER_MASK],usid,255)
        cmd_lst += write_cmd_generator(a[SIREV_ID],usid,238)
        cmd_lst += priv_dvt_write_all(usid,b)
        return cmd_lst
    def priv_dvt_read_sequence_1(usid,c,d):
        cmd_lst = pwr_rst_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[SIREV_ID],usid,64)
        cmd_lst += priv_dvt_read_all(usid,c,d)
        return cmd_lst
    def priv_dvt_read_sequence_2(usid,c,d):
        cmd_lst = pwr_rst_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[SIREV_ID],usid,0)
        cmd_lst += priv_dvt_read_all(usid,c,d)
        return cmd_lst
    def priv_dvt_read_sequence_3(usid,c,d):
        #This line reflects the lack of GSID reset in seq3 and 4
        temp = a[34].default
        a[34].default = '255'
        cmd_lst = udr_rst_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[SIREV_ID],usid,0)
        cmd_lst += priv_dvt_read_all(usid,c,d)
        a[34].default = temp
        return cmd_lst
    def priv_dvt_read_sequence_4(usid,c,d):
        #This line reflects the lack of GSID reset in seq3 and 4
        temp = a[34].default
        a[34].default = '255'
        cmd_lst = udr_rst_cmd_generator(usid)
        cmd_lst += rm_pm_trig_msk_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[SIREV_ID],usid,0)
        cmd_lst += priv_dvt_read_all(usid,c,d)
        a[34].default = temp
        return cmd_lst
    
    b = [reg for reg in a if type(reg)!=bool]
    b = [reg for reg in b if reg.address not in ctrl]        
    #c contains all reg addresses that are not ctrl regs and are implmnt req
    c = [reg.address for reg in b if reg.ireq=='Yes']
    #d contains all reg addrs that are not ctrl reg that are not implement req
    d = [reg.address for reg in b if reg.ireq=='No']
    #b contains only addresses to r/w registers that are not ctrl regs and are r/w
    b = [reg.address for reg in b if reg.r_w=='R/W']
    #b = [el for el in b if el<80]
    #c = [el for el in c if el<80]
    cmd_lst = priv_dvt_read_sequence_1(usid,c,d)
    cmd_lst += priv_dvt_write_sequence(usid,b)
    cmd_lst += priv_dvt_read_sequence_2(usid,c,d)
    cmd_lst += priv_dvt_write_sequence(usid,b)
    cmd_lst += priv_dvt_read_sequence_3(usid,c,d)
    cmd_lst += priv_dvt_write_sequence(usid,b)
    cmd_lst += priv_dvt_read_sequence_4(usid,c,d)
    return cmd_lst

def standard_write_read_test(usid,ctrl,rb_lst):
    def startup_sequence(usid):
        cmd_lst = pwr_rst_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[PM_TRIG],usid,128)
        cmd_lst += set_pm_trig_mask_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[EXT_TRIGGER_MASK],usid,255)
        cmd_lst += write_cmd_generator(a[SIREV_ID],usid,238)
        return cmd_lst
    def r_w_all(usid,b,val):
        cmd_lst = check_err_cmd_generator(usid)
        for adrs in b:
            cmd_lst += write_cmd_generator(a[adrs],usid,val)
            cmd_lst += check_err_cmd_generator(usid)
        for adrs in b:
            cmd_lst += read_cmd_generator(a[adrs],usid,val)
            cmd_lst += check_err_cmd_generator(usid)
        return cmd_lst
    def r_w_rb(usid,rb_lst,val):
        cmd_lst = check_err_cmd_generator(usid)
        for adrs in rb_lst:
            cmd_lst += write_cmd_generator(a[adrs],usid,val)
            cmd_lst += check_err_cmd_generator(usid)
        if val==0:
            for adrs in rb_lst:
                cmd_lst += read_cmd_generator(a[adrs],usid,val)
                cmd_lst += check_err_cmd_generator(usid)
            return cmd_lst
        val_lst = [15,15,15,15,15]
        for i in range(len(rb_lst)):
            cmd_lst += read_cmd_generator(a[rb_lst[i]],usid,val_lst[i])
            cmd_lst += check_err_cmd_generator(usid)
        return cmd_lst
    b = [reg for reg in a if type(reg)!=bool]
    b = [reg for reg in b if reg.address not in ctrl]
    b = [reg.address for reg in b if reg.ireq=='Yes' and reg.r_w=='R/W']
    cmd_lst = startup_sequence(usid)
    cmd_lst += r_w_all(usid,b,0)
    cmd_lst += r_w_all(usid,b,255)
    cmd_lst += r_w_all(usid,b,0)
    cmd_lst += r_w_rb(usid,rb_lst,0)
    cmd_lst += r_w_rb(usid,rb_lst,15)#DESI SPECIFIC
    cmd_lst += r_w_rb(usid,rb_lst,0)
    
    return cmd_lst
        
def triggered_write_test(usid,val):
    def priv_trig_meta_trigger(usid,trig):
        if ( trig < 3 ):
            return pm_trig_trigger_cmd_generator(usid,trig)
        else:
            return ext_trig_trigger_cmd_generator(usid,trig)
    
    def priv_trig_cmd_generator(address,usid,val,trig,target_trig):
        orval = val | a[address].default
        assert orval != a[address].default
        cmd_lst = write_cmd_generator(a[address],usid,orval)
        cmd_lst += priv_trig_meta_trigger(usid,trig)
        if ( trig==target_trig ):
            cmd_lst += read_cmd_generator(a[address],usid,orval)
            cmd_lst += write_cmd_generator(a[address],usid,a[address].default)
            cmd_lst += priv_trig_meta_trigger(usid,trig)
        else:
            cmd_lst += read_cmd_generator(a[address],usid,a[address].default)
        return cmd_lst
    
    cmd_lst = []
    b = [reg for reg in a if type(reg)!=bool]
    b = [reg.address for reg in b if reg.trig_sup=='Yes']
    
    for adrs in b:
        target_trig = trig_dict[a[adrs].trigger]
        cmd_lst += pwr_rst_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[45],usid,0)
        cmd_lst += set_ext_trig_mask_cmd_generator(usid)
        cmd_lst += read_cmd_generator(a[45],usid,255)
        cmd_lst += rm_pm_trig_msk_cmd_generator(usid)
        cmd_lst += rm_ext_trig_msk_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[adrs],usid,val)
        cmd_lst += read_cmd_generator(a[adrs],usid,a[adrs].default)
        for trig in trig_dict.values():
            cmd_lst += priv_trig_cmd_generator(adrs,usid,val,trig,target_trig)
    return cmd_lst                

def extended_write_test(usid,val,ctrl,rb_lst):
    def priv_test_sequence(reg,usid,vals):
        cmd_lst = pwr_rst_cmd_generator(usid)
        cmd_lst += set_pm_trig_mask_cmd_generator(usid)
        cmd_lst += set_ext_trig_mask_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[SIREV_ID],usid,238)
        for val in vals:
            cmd_lst += extend_write_cmd_generator(reg,usid,val)
            cmd_lst += extend_read_cmd_generator(reg,usid,val)
        cmd_lst += check_err_cmd_generator(usid)
        return cmd_lst    
    def priv_test_pm_trig(usid):
        cmd_lst = pwr_rst_cmd_generator(usid)
        cmd_lst += priv_test_sequence(a[PM_TRIG],usid,[56,48,56])
        return cmd_lst
    def priv_test_udr_rst(usid):
        cmd_lst = set_ext_trig_mask_cmd_generator(usid)
        cmd_lst += write_cmd_generator(a[1],usid,15)
        cmd_lst += read_cmd_generator(a[1],usid,15)
        cmd_lst += extend_write_cmd_generator(a[UDR_RST],usid,128)
        cmd_lst += extend_read_cmd_generator(a[UDR_RST],usid,0)
        cmd_lst += read_cmd_generator(a[1],usid,a[1].default)
        return cmd_lst
    def priv_test_err_sum(usid):
        cmd_lst = write_cmd_generator(a[20],usid,255)
        cmd_lst += read_cmd_generator(a[20],usid,0)
        cmd_lst += extend_read_cmd_generator(a[ERR_SUM],usid,6)
        return cmd_lst
    def priv_test_bus_ld(usid):
        cmd_lst = extend_read_cmd_generator(a[BUS_LD],usid,a[BUS_LD].default)
        cmd_lst += extend_write_cmd_generator(a[BUS_LD],usid,a[BUS_LD].default+2)
        cmd_lst += extend_read_cmd_generator(a[BUS_LD],usid,a[BUS_LD].default+2)
        cmd_lst += extend_write_cmd_generator(a[BUS_LD],usid,a[BUS_LD].default)
        return cmd_lst
    def priv_test_ext_trig_mask(usid):
        cmd_lst = pwr_rst_cmd_generator(usid)
        cmd_lst += extend_read_cmd_generator(a[EXT_TRIGGER_MASK],usid,a[EXT_TRIGGER_MASK].default)
        cmd_lst += extend_write_cmd_generator(a[EXT_TRIGGER_MASK],usid,255)
        cmd_lst += extend_read_cmd_generator(a[EXT_TRIGGER_MASK],usid,255)
        cmd_lst += extend_write_cmd_generator(a[EXT_TRIGGER_MASK],usid,0)
        return cmd_lst
    def priv_test_ext_trigger(usid):
        cmd_lst = write_cmd_generator(a[1],usid,15)
        cmd_lst += read_cmd_generator(a[1],usid,a[1].default)
        cmd_lst += extend_write_cmd_generator(a[EXT_TRIGGER],usid,255)
        cmd_lst += read_cmd_generator(a[1],usid,15)
        return cmd_lst
    def priv_test_test_patt(usid):
        return extend_read_cmd_generator(a[TEST_PATT],usid,a[TEST_PATT].default)
    
    b = [reg for reg in a if type(reg)!=bool]
    b = [reg for reg in b if reg.address not in ctrl]
    b = [reg.address for reg in b if reg.ext_rw=='Yes']
    rb_lst = [rb for rb in rb_lst if a[rb].ext_rw=='Yes']
    cmd_lst = priv_test_pm_trig(usid)
    cmd_lst += priv_test_udr_rst(usid)
    cmd_lst += priv_test_err_sum(usid)
    cmd_lst += priv_test_bus_ld(usid)
    cmd_lst += priv_test_ext_trig_mask(usid)
    #Determine if there are any extended triggers in the chip
    trig_lst = [reg.trigger for reg in a if (type(reg)!=bool and reg.trigger!='N/A')]
    trig_lst = [True if 'EXT' in t else False for t in trig_lst]
    #No reason to test if there arent any.
    if any(trig_lst):
        cmd_lst += priv_test_ext_trigger(usid)
    cmd_lst += priv_test_test_patt(usid)
    cmd_lst += pwr_rst_cmd_generator(usid)
    cmd_lst += set_pm_trig_mask_cmd_generator(usid)
    cmd_lst += write_cmd_generator(a[EXT_TRIGGER_MASK],usid,255)
    cmd_lst += write_cmd_generator(a[SIREV_ID],usid,238)
    for adrs in b:
        cmd_lst += priv_test_sequence(a[adrs],usid,[0,255,0])
    for adrs in rb_lst:
        orval = 15 #val | a[adrs].default
        assert orval != a[adrs].default
        cmd_lst += priv_test_sequence(a[adrs],usid,[0,orval,0])
    return cmd_lst

def fuseburn_readback(usid,num_banks):
    cmd_lst = pwr_rst_cmd_generator(usid)
    cmd_lst += set_pm_trig_mask_cmd_generator(usid)
    cmd_lst += set_ext_trig_mask_cmd_generator(usid)
    cmd_lst += write_cmd_generator(a[FUSE],usid,0)
    #For every bank
    for i in range(num_banks):
        #Select a bank
        cmd_lst += write_cmd_generator(a[BANK],usid,128+i)
        #NOP's to give the FBRB regs time to fill.
        for j in range(5):
            #We've set the masks, so we should expect to see 56 in PM_TRIG. Read five times for delay.
            cmd_lst += read_cmd_generator(a[PM_TRIG],usid,56)
        #Read from the FBRB registers
        for adrs in FB_READBACK:
            cmd_lst += read_cmd_generator(a[adrs],usid,0)
    return cmd_lst

def revid_test(usid):
    def priv_revid_test_gen(usid,reg,val,por=True,udr=True,unlock=True):
        cmd_lst = []    
        if por:
            cmd_lst += pwr_rst_cmd_generator(usid)
        if udr:
            cmd_lst += udr_rst_cmd_generator(usid)
        if unlock:
            cmd_lst += write_cmd_generator(a[164],usid,238)
        cmd_lst += read_cmd_generator(reg,usid,reg.default)
        cmd_lst += write_cmd_generator(reg,usid,val)
        cmd_lst += read_cmd_generator(reg,usid,val)
        
        return cmd_lst
    #First test: does por work when unlocked
    cmd_lst = priv_revid_test_gen(usid,a[33],a[33].default,por=True,udr=False,unlock=True)
    cmd_lst += priv_revid_test_gen(usid,a[33],255,por=True,udr=False,unlock=True)
    cmd_lst += priv_revid_test_gen(usid,a[33],a[33].default,por=True,udr=False,unlock=True)
    
    #Second test: does udr work when unlocked
    cmd_lst += priv_revid_test_gen(usid,a[33],a[33].default,por=True,udr=False,unlock=True)
    cmd_lst += priv_revid_test_gen(usid,a[33],255,por=True,udr=False,unlock=True)
    cmd_lst += priv_revid_test_gen(usid,a[33],a[33].default,por=False,udr=True,unlock=True)
    
    #Third test: does udr reset the lock?
    cmd_lst += priv_revid_test_gen(usid,a[33],a[33].default,por=True,udr=False,unlock=True)
    cmd_lst += priv_revid_test_gen(usid,a[33],255,por=True,udr=False,unlock=True)
    cmd_lst += priv_revid_test_gen(usid,a[33],a[33].default,por=False,udr=True,unlock=False)
    cmd_lst += priv_revid_test_gen(usid,a[33],a[33].default,por=True,udr=False,unlock=True)
    return cmd_lst
    
def lfem_tester():
    def priv_reset_with_masking(rst_usid):
        #Reset the device
        cmd_lst = pwr_rst_cmd_generator(rst_usid,useusid=True)
        #set triggers for both usid
        #Trigger1 for usid7
        cmd_lst += set_pm_trig_mask_cmd_generator(7,mask=1)
        #Trigger2 for usidF
        cmd_lst += set_pm_trig_mask_cmd_generator(15,mask=2)
        return cmd_lst
    def priv_double_read(reg,erd):
        cmd_lst = read_cmd_generator(reg,7,erd)
        cmd_lst += read_cmd_generator(reg,15,erd)
        return cmd_lst
    def priv_double_write(reg,wrt):
        cmd_lst = write_cmd_generator(reg,7,wrt)
        cmd_lst += write_cmd_generator(reg,15,wrt)
        return cmd_lst
    def priv_double_chk_err():
        cmd_lst = check_err_cmd_generator(7)
        cmd_lst += check_err_cmd_generator(15)
        return cmd_lst
    
    #Demonstrate that psemi registers are shared.
    cmd_lst = priv_reset_with_masking(0)
    cmd_lst += write_cmd_generator(a[180],7,255)
    cmd_lst += priv_double_read(a[180],255)
    cmd_lst += priv_reset_with_masking(0)
    
    #Test for shared PM_TRIG powered reset
    for el in [7,15]:    
        #Read from reg0 each usid
        cmd_lst += priv_double_read(a[0],0)
        #Write to reg0 of each usid
        cmd_lst += priv_double_write(a[0],15)
        #Read from each usid
        cmd_lst += priv_double_read(a[0],15)
        #Reset and read from each usid
        cmd_lst += priv_reset_with_masking(el)
        cmd_lst += priv_double_read(a[0],0)
    
    #Test for shared UDR_RST reset
    for el in [7,15]:
        cmd_lst += priv_reset_with_masking(0)
        cmd_lst += priv_double_write(a[0],15)
        cmd_lst += priv_double_read(a[0],15)
        cmd_lst += udr_rst_cmd_generator(el)
        cmd_lst += priv_double_read(a[0],0)
    
    #Test entrance and exits of PAMID from LFEM
    for el in [7,15]:
        cmd_lst += priv_reset_with_masking(0)
        cmd_lst += priv_double_write(a[0],15)
        cmd_lst += priv_double_read(a[0],15)
        cmd_lst += priv_double_read(a[1],15)
        for val in [2,0]:
            cmd_lst += write_cmd_generator(a[184],el,val)
            cmd_lst += priv_double_read(a[0],15)
            cmd_lst += priv_double_read(a[1],15)
    
    #Test for UDR_RST exit from PAMID
    for el in [7,15]:
        cmd_lst += priv_reset_with_masking(0)
        cmd_lst += priv_double_read(a[1],0)
        for inner_el in [7,15]:
            cmd_lst += write_cmd_generator(a[184],el,2)
            cmd_lst += priv_double_read(a[1],0)
            cmd_lst += priv_double_chk_err()
            cmd_lst += udr_rst_cmd_generator(inner_el)
            cmd_lst += priv_double_read(a[1],0)
            cmd_lst += priv_reset_with_masking(0)
    return cmd_lst
 
    
hdr_str = ['#,setup_header,test_system,Manual,,,\n']
hdr_str += ['#,setup_header,version,1,,,\n']
hdr_str += ['#,MipiVerification,clusters,,,,\n']
hdr_str += ['enabled,type,usid,regAddr,writeMask,regWriteData,expectedReadData,regWriteArrayItem0,regWriteArrayItem1,regWriteArrayItem2\n']

out_file_dir = 'J:/joslaton/INU/MIPI_Verification/Generated/'
out_file_name = ['Reg0Write.csv',
                 'Programmable_USID.csv',
                 'Masked_Write.csv',
                 'Default_Values.csv',
                 'Std_Write.csv',
                 'Triggered_Write_Test.csv',
                 'Extended_Write_Test.csv',
                 'Fuseburn_ReadBack_Test.csv']

in_file_dir = 'J:/joslaton/INU/MIPI_Verification/'
in_file_stand = 'INU_PRD_STAND_REG_USID_1.csv'
in_file_extend= 'INU_PRD_EXT_REG.csv'

usid = 1

a = register_pack_generator(in_file_dir,in_file_stand,in_file_extend)

output = [hdr_str + reg_zero_write(usid)]
output += [hdr_str + prog_USID(usid,3)]
output += [hdr_str + mask_write_tester(usid)]
#output += [hdr_str + timed_triggers(usid)]
output += [hdr_str + default_values_test(usid,control_reg_lst)]
output += [hdr_str + standard_write_read_test(usid,exclude_lst,has_bits_reserved_lst)]
output += [hdr_str + triggered_write_test(usid,15)]
output += [hdr_str + extended_write_test(usid,28,exclude_lst,has_bits_reserved_lst)]
output += [hdr_str + fuseburn_readback(usid,4)]
#output += [hdr_str + reg_zero_error_tester(usid)]


for i in range(len(output)):
    with open(out_file_dir+out_file_name[i],'w') as f:
        f.writelines(output[i])

