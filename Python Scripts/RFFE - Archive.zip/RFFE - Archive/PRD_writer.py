# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 16:22:05 2019

@author: joslaton
"""

import pandas as pd
import copy


def parse_extended_bits(df):
    len_lst = list(map(lambda x: len(x),df['Default']))
    idx_lst1 = [i for i in range(len(len_lst)) if len_lst[i]<5]
    df['Default'].iloc[idx_lst1] = list(map(lambda x: int(x,16),df['Default'].iloc[idx_lst1]))
    return df

def parse_bits(df):
    #Make a list containing the lengths of the default value strings
    len_lst = list(map(lambda x: len(x),df['Default']))
    
    idx_lst1 = [i for i in range(len(len_lst)) if len_lst[i]==1]
    idx_lst2 = [i for i in range(len(len_lst)) if len_lst[i]==8]
    df['Default'].iloc[idx_lst1] = list(map(lambda x: int(x[0],16),df['Default'].iloc[idx_lst1]))
    df['Default'].iloc[idx_lst2] = list(map(lambda x: int(''.join(x),2),df['Default'].iloc[idx_lst2]))
    idx_lst3 = [i for i in range(len(len_lst)) if len_lst[i]!=1 and len_lst[i]!=8]
    idx_lst4 = [el for el in idx_lst3 if 'x' not in ''.join(df['Default'].iloc[el])]
    #idx_lst5 = [el for el in idx_lst3 if 'x' in ''.join(df['Default'].iloc[el])]
    df['Default'].iloc[idx_lst4] = list(map(lambda x: int(''.join(x).replace(' ',''),2),df['Default'].iloc[idx_lst4]))
    return df
    
    
def concat_bits(idx_lst,df):
    i = 0
    a_lst = []
    while i < (len(idx_lst)-1):
        a_lst = [str(el) for el in df['Default'].iloc[idx_lst[i]:idx_lst[i+1]] if type(el)!=bool]
        df['Default'].iloc[idx_lst[i]] = a_lst
        i+=1
    if (df.iloc[-1].name==df.iloc[idx_lst[i]].name):
        a_lst = [str(df['Default'].iloc[-1])]
    else:
        a_lst = [str(el) for el in df['Default'].iloc[idx_lst[i]] if type(el)!=bool]
    df['Default'].iloc[idx_lst[i]] = a_lst
    df = df.iloc[idx_lst].reset_index(drop=True)
    return df

def insert_rows(idx, df, df_insert,offset):
    dfA = df.iloc[:idx, ]
    dfB = df.iloc[idx+offset:, ]
    
    df = dfA.append(df_insert).append(dfB).reset_index(drop = True)
    
    return df

def df_cleaner(df):
    #Drop NaN rows and reindex.
    df.dropna(axis=0,how='all',inplace=True)
    df = df.reset_index(drop=True)
    #Get the index of the 48-55 registers. 
    small_df = df[df['Register Address (Dec.)'].str.contains('-').fillna(False)]
    idx = small_df.index[0]
    #Create rows to be inserted.
    small_df = small_df.append([small_df.iloc[0]]*7,ignore_index=True)
    temp_reg_lst = [i for i in range(48,56)]
    hex_temp_reg_lst = [hex(i) for i in temp_reg_lst]
    small_df['Register Address (Dec.)'] = temp_reg_lst
    small_df['Register Address (Hex.)'] = hex_temp_reg_lst
    df = insert_rows(idx,df,small_df,2).fillna(False)
    idx_lst = df['Implementation Required'].where(df['Implementation Required'].astype(bool)).dropna().index.tolist()
    df = concat_bits(idx_lst,df)
    return df
        
    

prd_sheet_stand_reg = 'X Reg Map Dev2'
prd_sheet_ext_reg = 'C0Vx Ext Reg Map'
prd_file = 'J:\joslaton\LIGER\DESI_MIPI_Verification\PE478110 DESI PRD.xlsx'

stand_reg_df = df_cleaner(pd.read_excel(prd_file,sheet_name=prd_sheet_stand_reg,header=1,
                             usecols=[1,2,3,9,18,19,20,21,22]))#[1,2,3,4,6,9,20,21,22,23,24,26]))


tst_df = copy.deepcopy(stand_reg_df)

tst_df = parse_bits(tst_df)

tst_df['Register Address (Dec.)'] = list(map(lambda x: int(x,16),tst_df['Register Address (Hex.)']))
#tst_df.drop(labels='Data Bits',axis=1,inplace=True)

#tst_df['Default'].iloc[1] = 0
#tst_df['Default'].iloc[8] = int('00010010',2)
tst_df['Default'].iloc[31] = int('0x21',16)
tst_df['Default'].iloc[33] = 0
tst_df['Default'].iloc[34] = int('11110000',2)
tst_df['Default'].iloc[37] = 0
tst_df['Default'].iloc[38] = 0
tst_df['Default'].iloc[43] = int('00000100',2)
#Print to file
tst_df.to_csv(path_or_buf='J:\joslaton\LIGER\DESI_MIPI_Verification\DESI_PRD_STAND_REG.csv',index=False)
#del stand_reg_df
stand_reg_df = tst_df

'''
EXTENDED REGISTER CLEANING
'''
prd_sheet_ext_reg = 'pSemi Ext Reg Map'
prd_file = 'J:\joslaton\LIGER\DESI_MIPI_Verification\pSemi Extended Register Map DESI.xlsx'
ext_reg_df = pd.read_excel(prd_file,sheet_name=prd_sheet_ext_reg,header=1)

tst_df = copy.deepcopy(ext_reg_df)
tst_df = tst_df.dropna(axis=0,thresh=8)
tst_df = tst_df.rename(lambda x: x.replace('\n',' '),axis='columns')
tst_df = tst_df.rename(index=str, columns={'Default (Hex.)':'Default'})
tst_df.insert(0,'Implementation Required',
              ['Yes' for i in range(len(tst_df['Fused']))])
tst_df.insert(1,'Register Address (Dec.)',
              list(map(lambda x: int(x,16),tst_df['Register Address (Hex.)'])))
drop_lst = ['Register Name','Number of Bits','Description','TBYB','Comment','Mask Default','Fused']
tst_df = tst_df.drop(drop_lst,axis=1)
tst_df = tst_df.replace(to_replace={'Y':'Yes','N':'No'})

for i in range(len(tst_df['Implementation Required'])):
    if ( tst_df['Reserved Bit Mask'].iloc[i] == 'Yes' ):
        tst_df['Implementation Required'].iloc[i] = 'No'

drop_lst = ['Reserved Bit Mask']
tst_df = tst_df.drop(drop_lst,axis=1)
tst_df.insert(6,'Extended Register R/W',
              ['Yes' for i in range(len(tst_df['Default']))])
tst_df.insert(8,'R/W',
              ['R/W' for i in range(len(tst_df['Default']))])
tst_df.to_csv(path_or_buf='J:\joslaton\LIGER\DESI_MIPI_Verification\DESI_PRD_EXT_REG.csv',index=False)
'''
drop_lst = [el for el in tst_df.columns.tolist() if 'Unnamed' in el]
drop_lst += ['Register Name']
drop_lst += ['Function']
drop_lst += ['Fused']
drop_lst += ['TBYB']
drop_lst += ['Comment']
tst_df = tst_df.drop(drop_lst,axis=1)
del drop_lst
tst_df['MIPI Address'].fillna(False,inplace=True)
tst_df = tst_df.rename(index=str,
                       columns={'MIPI Address':'Register Address (Hex.)',
                                'Trigger':'Active Trigger',
                                'Mask-Write Support':'Masked Write Support'})
idx_lst = [i for i in range(len(tst_df['Register Address (Hex.)'])) if
           type(tst_df['Register Address (Hex.)'].iloc[i])==bool]
tst_df = tst_df.drop(tst_df.index[idx_lst]).reset_index(drop=True)
idx_lst = [i for i in range(len(tst_df['Register Address (Hex.)'])) if '-' in tst_df['Register Address (Hex.)'].iloc[i]]
tst_df = tst_df.drop(tst_df.index[idx_lst]).reset_index(drop=True)

tst_df.insert(0,'Register Address (Dec.)',
              list(map(lambda x: int(x,16),tst_df['Register Address (Hex.)'])))
idx_lst = [i for i in range(len(tst_df['Register Address (Hex.)'])) if tst_df['Register Address (Dec.)'].iloc[i]<128]
tst_df = tst_df.drop(tst_df.index[idx_lst]).reset_index(drop=True)

#tst_df.insert(4,'Trigger Support',
#              ['Yes' for i in range(len(tst_df['Trigger Support']))])
'''
'''
tst_df = tst_df.iloc[:-1]
tst_df = tst_df.drop(axis=0,index=6).reset_index(drop=True)
tst_df = tst_df.drop(columns=['Comments','RegName','No. Bits','Description','TBYB'])
tst_df = tst_df.rename(index=str,
                       columns={'MIPI Address':'Register Address (Hex.)',
                                'Trigger':'Trigger Support',
                                'Mask-Write Support':'Masked Write Support'})
tst_df['Trigger Support'] = ['No' for i in range(len(tst_df['Trigger Support'])) if
      tst_df['Trigger Support'].iloc[i]=='N']
tst_df['Masked Write Support'] = ['No' for i in range(len(tst_df['Trigger Support'])) if
      tst_df['Masked Write Support'].iloc[i]=='N']
tst_df.insert(0,'Register Address (Dec.)',
              list(map(lambda x: int(x,16),tst_df['Register Address (Hex.)'])))
tst_df.insert(3,'Active Trigger ',
              [False for i in range(len(tst_df['Trigger Support'])) if 
               tst_df['Trigger Support'].iloc[i]=='No'])
tst_df.insert(2,'Register Type',
              [False for i in range(len(tst_df['Trigger Support']))])
tst_df.insert(0,'Implementation Required',
              ['Yes' for i in range(len(tst_df['Trigger Support']))])
tst_df.insert(0,'Extended Register R/W',
              ['Yes' for i in range(len(tst_df['Trigger Support']))])
tst_df.insert(1,'R/W',
              ['R/W' for i in range(len(tst_df['Trigger Support']))])
tst_df = tst_df[stand_reg_df.columns.tolist()]
tst_df = parse_extended_bits(tst_df)

tst_df.to_csv(path_or_buf='J:\joslaton\LIGER\DESI_MIPI_Verification\DESI_PRD_EXT_REG.csv',index=False)
'''