# -*- coding: utf-8 -*-
"""
Created on Thu May 16 11:26:37 2019

@author: joslaton
"""



import pandas as pd
from copy import deepcopy


def parse_extended_bits(df):
    len_lst = list(map(lambda x: len(x),df['Default']))
    idx_lst1 = [i for i in range(len(len_lst)) if len_lst[i]<5]
    df['Default'].iloc[idx_lst1] = list(map(lambda x: int(x,16),df['Default'].iloc[idx_lst1]))
    return df

def parse_bits(df):
    #Make a list containing the lengths of the default value strings
    len_lst = list(map(lambda x: len(x),df['Default']))
    
    idx_lst1 = [i for i in range(len(len_lst)) if len_lst[i]==1]
    idx_lst2 = [i for i in range(len(len_lst)) if len_lst[i]==8]
    df['Default'].iloc[idx_lst1] = list(map(lambda x: int(x[0],16),df['Default'].iloc[idx_lst1]))
    df['Default'].iloc[idx_lst2] = list(map(lambda x: int(''.join(x),2),df['Default'].iloc[idx_lst2]))
    idx_lst3 = [i for i in range(len(len_lst)) if len_lst[i]!=1 and len_lst[i]!=8]
    idx_lst4 = [el for el in idx_lst3 if 'x' not in ''.join(df['Default'].iloc[el])]
    #idx_lst5 = [el for el in idx_lst3 if 'x' in ''.join(df['Default'].iloc[el])]
    df['Default'].iloc[idx_lst4] = list(map(lambda x: int(''.join(x).replace(' ',''),2),df['Default'].iloc[idx_lst4]))
    return df
    
    
def concat_bits(idx_lst,df):
    i = 0
    a_lst = []
    while i < (len(idx_lst)-1):
        a_lst = [str(el) for el in df['Default'].iloc[idx_lst[i]:idx_lst[i+1]] if type(el)!=bool]
        df['Default'].iloc[idx_lst[i]] = a_lst
        i+=1
    if (df.iloc[-1].name==df.iloc[idx_lst[i]].name):
        a_lst = [str(df['Default'].iloc[-1])]
    else:
        a_lst = [str(el) for el in df['Default'].iloc[idx_lst[i]] if type(el)!=bool]
    df['Default'].iloc[idx_lst[i]] = a_lst
    df = df.iloc[idx_lst].reset_index(drop=True)
    return df

def insert_rows(idx, df, df_insert,offset):
    dfA = df.iloc[:idx, ]
    dfB = df.iloc[idx+offset:, ]
    '''
    print(dfA)
    print(df_insert)
    print(dfB)
    '''
    df = dfA.append(df_insert).append(dfB).reset_index(drop=True)
    return df

def df_cleaner(df):
    #Drop NaN rows and reindex.
    df.dropna(axis=0,how='all',inplace=True)
    df = df.reset_index(drop=True)
    #Get the index of the 48-55 registers. 
    small_df = df[df['Register Address (Dec.)'].str.contains('-').fillna(False)]
    adx = small_df['Register Address (Dec.)'].tolist()
    begin_adx = [int(el.split('-')[0]) for el in adx]
    end_adx = [int(el.split('-')[1]) for el in adx]
    #Create rows to be inserted.
    for i in range(len(adx)):
        span = end_adx[i]-begin_adx[i]+1
        temp_df = pd.DataFrame([small_df.iloc[i]]*span)
        #print(temp_df)
        temp_reg_lst = [i for i in range(begin_adx[i],end_adx[i]+1)]
        #print(temp_reg_lst)
        hex_temp_reg_lst = [hex(i) for i in temp_reg_lst]
        temp_df['Register Address (Dec.)'] = temp_reg_lst
        temp_df['Register Address (Hex.)'] = hex_temp_reg_lst
        smaller_df = df[df['Register Address (Dec.)'].str.contains('-').fillna(False)]
        idx_lst = smaller_df.index.tolist()
        df = insert_rows(idx_lst[0],df,temp_df,1).fillna(False)
    idx_lst2 = df['Implementation Required'].where(df['Implementation Required'].astype(bool)).dropna().index.tolist()
    df = concat_bits(idx_lst2,df)
    return df
        
 #%%   

prd_sheet_stand_reg = 'MIMO_DSM RegMap v3p0 Dev3'
prd_file = r"\\malibu\benchdata\1_Engineers\joslaton\KRYPTON\Docs\KRYPTON_REG_MAP.xlsx"

#%%


stand_reg_df = pd.read_excel(prd_file,sheet_name=prd_sheet_stand_reg,header=1,
                             usecols=['Implementation Required',
                                      'Register Address (Dec.)',
                                      'Register Address (Hex.)',
                                      'Default',
                                      'Trigger Support',
                                      'Active Trigger',
                                      'Extended Register R/W',
                                      'Masked Write Support',
                                      'R/W'])

#%%
stand_reg_df = df_cleaner(stand_reg_df)

#%% ArgonSpecific
stand_reg_df['Masked Write Support'] = [el if el!='No*' else 'Yes' for el in stand_reg_df['Masked Write Support']]
stand_reg_df['Masked Write Support'] = [el if el else 'No' for el in stand_reg_df['Masked Write Support']]
stand_reg_df['Extended Register R/W'] = [el if el else 'No' for el in stand_reg_df['Extended Register R/W']]
stand_reg_df['Active Trigger'] = [el if el else 'N/A' for el in stand_reg_df['Active Trigger']]
stand_reg_df['Trigger Support'] = [el if el else 'No' for el in stand_reg_df['Trigger Support']]
stand_reg_df['Implementation Required'] = [el if el!='Optional' else 'Yes' for el in stand_reg_df['Implementation Required']]

#%%

stand_reg_df = parse_bits(stand_reg_df)

stand_reg_df['Register Address (Dec.)'] = list(map(lambda x: int(x,16),stand_reg_df['Register Address (Hex.)']))

#stand_reg_df.index = stand_reg_df['Register Address (Dec.)'].values
#stand_reg_df = stand_reg_df.reindex(pd.RangeIndex(75))

#%%


#%%
#Print to file
stand_reg_df.to_csv(path_or_buf='J:\joslaton\KRYPTON\MIPI_Verification\KRYPTON_PRD_STAND_REG.csv',index=False)

#%%
'''
EXTENDED REGISTER CLEANING
'''

prd_sheet_ext_reg = 'Krypton_RevB0_EXTMAP'

ext_reg_df = pd.read_excel(prd_file,sheet_name=prd_sheet_ext_reg,header=0,
                           usecols=['Register Address (Hex.)',
                                    'Implementation Required',
                                    'Default',
                                    'Triggered',
                                    'Masked Write'])

#%%

temp_lst = ext_reg_df['Register Address (Hex.)'].values.tolist()
temp_lst = [str(int(el,16)) if (type(el)==str and len(el)==4) else el for el in temp_lst]
temp_lst[5] = '132 - 159'
temp_lst[0] = '74 - 127'
ext_reg_df['Register Address (Dec.)'] = temp_lst

#%%

ext_reg_df = df_cleaner(ext_reg_df)


#%%

ext_reg_df = parse_bits(ext_reg_df)

#%%

ext_reg_df = ext_reg_df.rename(index=str,columns={'Masked Write':'Masked Write Support',
                                          'Triggered':'Trigger Support'})

#%%
ext_reg_df['Register Address (Dec.)'] = list(map(lambda x: int(x,16),ext_reg_df['Register Address (Hex.)']))
ext_reg_df['Masked Write Support'] = ['Yes' if el=='Y' else 'No' for el in ext_reg_df['Masked Write Support']]
ext_reg_df['Active Trigger'] = [el if (el and el!='N') else 'N/A' for el in ext_reg_df['Trigger Support']]
ext_reg_df['Trigger Support'] = ['Yes' if (el and el!='N') else 'No' for el in ext_reg_df['Trigger Support']]
ext_reg_df['Extended Register R/W'] = ['Yes' for el in ext_reg_df['Register Address (Hex.)']]
ext_reg_df['R/W'] = ['R/W' for el in ext_reg_df['Register Address (Hex.)']]


#%%
ext_reg_df = ext_reg_df[['Implementation Required',
                      'Register Address (Dec.)',
                      'Register Address (Hex.)',
                      'Default',
                      'Trigger Support',
                      'Active Trigger',
                      'Extended Register R/W',
                      'Masked Write Support',
                      'R/W']]

ext_reg_df.to_csv(path_or_buf='J:\joslaton\KRYPTON\MIPI_Verification\KRYPTON_PRD_EXT_REG.csv',index=False)