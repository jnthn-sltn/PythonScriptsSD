# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 14:44:16 2019

@author: joslaton
"""

import record_splitter as rs
import pandas as pd
import os

def filename_collector(fdir):
    a = []
    for root, dirs, files in os.walk(fdir):  
        for filename in files:
            a += [filename]
    return a

def print_all_to_file(rh,fdir):
    for rec in rh:
        rec.print_to_file(fdir)

def test_cat(rh=None,fdir=None):
    #If no record holder is passed
    if (rh == None):
        #
        flist = filename_collector(fdir)
        d_list = []
        for fname in flist:
            df = pd.read_csv(fdir+fname,index_col=None,header=0)
            d_list.append(df)
        df2 = pd.concat(d_list, axis=0, ignore_index=True)
        df2.dropna(axis=1,how='all',inplace=True)
        return df2
        #return df2.dropna(axis=1,how='all',inplace=True)
    else:
        d_list = []
        d_list += [rec_holder[0].col_header]
        for rec in rh:
            for line in rec.result:
                d_list.append(line)
        for i in range(len(d_list)):
            d_list[i] = d_list[i].split(',')
        for i in range(len(d_list[0])):
            d_list[0][i] = d_list[0][i].strip()
        df = pd.DataFrame(data=d_list[1:],index=None, columns=d_list[0])
        df.mask((df=='')|(df=='\n'),inplace=True)
        df.dropna(axis=1,how='all',inplace=True)
        return df

    
        

tdata_fdir = 'J:/joslaton/INU_B0V1_BOLT/Interposer 6/Data/'
tdata_fname = 'INU_USID5_DATA_03_11_2019.csv'

rec_holder = rs.read_test_csv(tdata_fdir + tdata_fname)
rec_holder = rs.split_records(rec_holder)

print_all_to_file(rec_holder,tdata_fdir)

splits_fdir = tdata_fdir + 'Splits/USID1/'

flist = filename_collector(splits_fdir)

all_tests_frame = test_cat(fdir=splits_fdir)
#all_tests_frame = test_cat(rh=rec_holder)

'''
:Name( "WriteSCLK_MaxFreq (MHz)" ),
:Name( "WriteSCLK_MinPeriod (ns)" ),
:Name( "ReadSCLK_MaxFreq (Derated) (MHz)" ),
:Name( "ReadSCLK_MinPeriod (Derated) (ns)" ),
:Name( "Setup_Time (ns)" ),
:Name( "Hold_Time (ns)" ),
:Name( "SCLK min high time (Derated) (ns)" ),
:Name( "SCLK min low time (ns)" ),
:Name( "Dstab time (Derated) (ns)" ),
:Name( "SDATA VOH 1mA (V)" ),
:Name( "SDATA VOL 1mA (V)" ),
:Name( "SDATA VOH 2mA (V)" ),
:Name( "SDATA VOL 2mA (V)" ),
:Name( "SDATA IIH (uA)" ),
:Name( "SDATA IIL (uA)" ),
:Name( "SCLK IIH (uA)" ),
:Name( "SCLK IIL (uA)" ),
:Name( "VIH (SDATA) (V)" ),
:Name( "VIH (SCLK) (V)" ),
:Name( "VIL (SDATA) (V)" ),
:Name( "VIL (SCLK) (V)" ),
:Name( "VIO current (uA)" )
'''



















